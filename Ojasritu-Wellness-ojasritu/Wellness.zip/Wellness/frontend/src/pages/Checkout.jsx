import React from 'react'

export default function Checkout() {
  return (
    <div className="container">
      <h2>Checkout</h2>
      <p>This is a demo checkout. Configure Razorpay keys and backend order creation to enable payments.</p>
    </div>
  )
}
