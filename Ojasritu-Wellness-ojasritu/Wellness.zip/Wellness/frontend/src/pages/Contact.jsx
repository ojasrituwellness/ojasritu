import React from 'react'

function Contact() {
  return (
    <div>
      <h1>Contact Us</h1>
      <p>Get in touch with us for any questions or concerns.</p>
    </div>
  )
}

export default Contact