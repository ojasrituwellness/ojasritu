import React from 'react'

export default function Acharyas() {
  return (
    <div className="container">
      <h2>Contact Acharyas — Coming Soon</h2>
      <p>Expert chat/messaging will be available here. For now, you can request consultations via the contact form.</p>
    </div>
  )
}
