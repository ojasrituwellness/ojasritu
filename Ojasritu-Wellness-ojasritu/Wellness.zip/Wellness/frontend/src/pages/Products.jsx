import React from 'react'

function Products() {
  return (
    <div>
      <h1>Our Products</h1>
      <div className="products-grid">
        {/* Products will be loaded from the API */}
      </div>
    </div>
  )
}

export default Products