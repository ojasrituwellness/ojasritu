import React from 'react'

export default function Wellness() {
  return (
    <div className="container">
      <h2>Wellness Centre — Coming Soon</h2>
      <p>Gallery, booking, and centre details will appear here soon. This page serves as the scaffold for the future booking module.</p>
    </div>
  )
}
