import React from 'react'

export default function Cart() {
  return (
    <div className="container">
      <h2>Your Cart</h2>
      <p>No items in demo cart. Add products from the products page.</p>
    </div>
  )
}
